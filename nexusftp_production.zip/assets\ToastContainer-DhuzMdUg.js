import{E as y,_ as g,b as i,d as u,w as v,F as f,r as w,M as C,f as _,o as d,m as I,c as M,g as T,a as h,t as b,l as A}from"./index-5ttSWtlU.js";/**
 * @license lucide-vue-next v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var l={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};/**
 * @license lucide-vue-next v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const B=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();/**
 * @license lucide-vue-next v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=(e,t)=>({size:s,strokeWidth:n=2,absoluteStrokeWidth:o,color:c,class:m,...a},{attrs:p,slots:k})=>y("svg",{...l,width:s||l.width,height:s||l.height,stroke:c||l.stroke,"stroke-width":o?Number(n)*24/Number(s):n,...p,class:["lucide",`lucide-${B(e)}`],...a},[...t.map(x=>y(...x)),...k.default?[k.default()]:[]]);/**
 * @license lucide-vue-next v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E=r("CircleAlertIcon",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]]);/**
 * @license lucide-vue-next v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=r("CircleCheckBigIcon",[["path",{d:"M22 11.08V12a10 10 0 1 1-5.93-9.14",key:"g774vq"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]]);/**
 * @license lucide-vue-next v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Z=r("HardDriveIcon",[["line",{x1:"22",x2:"2",y1:"12",y2:"12",key:"1y58io"}],["path",{d:"M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",key:"oot6mr"}],["line",{x1:"6",x2:"6.01",y1:"16",y2:"16",key:"sgf278"}],["line",{x1:"10",x2:"10.01",y1:"16",y2:"16",key:"1l4acy"}]]);/**
 * @license lucide-vue-next v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=r("InfoIcon",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]]);/**
 * @license lucide-vue-next v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G=r("MoonIcon",[["path",{d:"M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z",key:"a7tn18"}]]);/**
 * @license lucide-vue-next v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const K=r("SunIcon",[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]]);/**
 * @license lucide-vue-next v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const D=r("TriangleAlertIcon",[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]]);/**
 * @license lucide-vue-next v0.359.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N=r("XIcon",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]),j={name:"ToastContainer",components:{CheckCircle:z,AlertCircle:E,AlertTriangle:D,Info:L,X:N},data(){return{toasts:[]}},mounted(){window.addEventListener("show-toast",this.handleToastEvent)},beforeUnmount(){window.removeEventListener("show-toast",this.handleToastEvent)},methods:{handleToastEvent(e){this.addToast(e.detail)},addToast({type:e="info",title:t,message:s,duration:n=4e3}){const o=Date.now()+Math.random();this.toasts.push({id:o,type:e,title:t,message:s}),setTimeout(()=>this.removeToast(o),n)},removeToast(e){this.toasts=this.toasts.filter(t=>t.id!==e)},toastClass(e){const t={success:"bg-emerald-50/90 dark:bg-emerald-900/30 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300",error:"bg-rose-50/90 dark:bg-rose-900/30 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300",warning:"bg-amber-50/90 dark:bg-amber-900/30 border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300",info:"bg-primary-50/90 dark:bg-primary-900/30 border-primary-200 dark:border-primary-800 text-primary-800 dark:text-primary-300"};return t[e]||t.info},toastIcon(e){return{success:"CheckCircle",error:"AlertCircle",warning:"AlertTriangle",info:"Info"}[e]||"Info"}}},q={class:"fixed top-4 right-4 z-[100] space-y-3 pointer-events-none"},H={class:"flex-1 min-w-0"},S={class:"text-sm font-medium"},V={key:0,class:"text-xs opacity-80 truncate"},X=["onClick"];function $(e,t,s,n,o,c){const m=_("X");return d(),i("div",q,[u(C,{name:"toast"},{default:v(()=>[(d(!0),i(f,null,w(o.toasts,a=>(d(),i("div",{key:a.id,class:I(["pointer-events-auto flex items-center gap-3 px-4 py-3 rounded-xl shadow-premium border min-w-[320px] max-w-md backdrop-blur-xl",c.toastClass(a.type)])},[(d(),M(T(c.toastIcon(a.type)),{class:"w-5 h-5 shrink-0"})),h("div",H,[h("p",S,b(a.title),1),a.message?(d(),i("p",V,b(a.message),1)):A("",!0)]),h("button",{onClick:p=>c.removeToast(a.id),class:"p-1 rounded-lg hover:bg-black/10 transition-colors shrink-0"},[u(m,{class:"w-4 h-4"})],8,X)],2))),128))]),_:1})])}const U=g(j,[["render",$],["__scopeId","data-v-45ecb04e"]]);export{z as C,Z as H,L as I,G as M,K as S,D as T,N as X,E as a,U as b,r as c};
